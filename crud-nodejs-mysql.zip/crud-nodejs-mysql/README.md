vamos a crear una carpeta con el comando mkdir y se llama crud_node_mysql 
el comando CD para entar en la carpeta.Dentro de la carpeta pondremos el comando
npm init --yes (esto este comando para crear un package.json y dentro de este package hay versiones,nombre,descripción etc...)

para instalar los modulos usaremos el comando.
(npm install express mysql express-myconnection morgan ejes).

Crearemos dentro de la carpeta principal una carpeta que se llama src

Dentro de la caepeta src creamos un archivo con el comando touch el archivo se llama app.js con la extension de javascript.
Dentro del archivo pondremos este codigo:
```javascript
#src/app.js

const express = require('express');
const app = express();
app.listen(app.get('port'), () => {
    console.log ('server on port 3000');
});
```
Despues arrancamos el servidor con este comando node src/app.js asi se arrancara el servidor despues en nevegador pondremos localhost:3000

Ahora vamos a crear una carpeta dentro de src que se llamara views.

vamos a instalar el modulo nodemon 
con el comando (npm install nodemon -D)

para arancar el servidor utilizaremos (npm run dev)
ahora utlizamos el comando npm run dev para iniciar el servidor


abrimos otro terminal y ejecutamos mysql con el comando (mysql -u root -p)
y ponemos la contraseña que hemos puesto en #src/app.js middlewares en esta caso hemos puesto contraseña

crear nueva carpeta llamada database que se encarga de tener los scripts de la base de datos.
para crear una carpeta con el comando mkdir.

creamos un archivo dentro de la carpeta database con el nombre db.sql

vamso a colocar este codigo dentro del archivo db.sql
```sql
-- creating the database
CREATE DATABASE crudnodejsmysql;

--using the database
use crudnodejsmysql;

-- creating a table
CREATE TABLE customer (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    phone VARCHAR(15)
);
--tp show all tables
SHOW TABLES;

-- to describe the table
describe customer;
```

copias esta codigo que acabamos de escribir y lo pegamos en la consola para crear la tabla y mostrarla.

utilizamos el siguente comando para saber si nuestra base de datos tiene datos 
```sql
select * from customer;
```

iniciamos el servidor y creamos tres carpetas llamadas routes , controllers y public
la carpeta routes es para poner todas la rutas del  servedor
la carpeta controllers es para ejecutar las rutas.
la carpeta public sirve para colocar los codijos fuentes (css ...)
```bash
npm run dev

mkdir /src/routes
mkdir /src/controller
mkdir /src/public
```
creamos un archivo dentro de la carpeta routes llamado customer.js


